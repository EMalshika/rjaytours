<?php
    include "connection.php";
    $price=0;
?>
<!DOCTYPE html>
<html lang="en" class=" ">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>RJAY Tours</title>
  <meta content="RJAY Tours Mobile App" name="description" />
  <meta content="themepassion" name="author" />


  <!-- App Icons -->
  <!--<link rel="apple-touch-icon" sizes="57x57" href="assets/images/icons/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="assets/images/icons/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="assets/images/icons/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="assets/images/icons/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="assets/images/icons/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="assets/images/icons/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="assets/images/icons/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="assets/images/icons/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/images/icons/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192" href="assets/images/icons/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="512x512" href="assets/images/icons/android-icon-512x512.png">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/images/icons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96" href="assets/images/icons/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/images/icons/favicon-16x16.png">-->
  <link rel="manifest" href="assets/images/icons/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/images/icons/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">






  <!-- CORE CSS FRAMEWORK - START -->
  <link href="assets/css/preloader.css" type="text/css" rel="stylesheet" media="screen" />

  <link href="modules/materialize/materialize.min.css" type="text/css" rel="stylesheet" media="screen" />
  <link href="modules/fonts/mdi/appicon/appicon.css" type="text/css" rel="stylesheet" media="screen" />
  <link href="modules/fonts/mdi/materialdesignicons.min.css" type="text/css" rel="stylesheet" media="screen" />
  <link href="modules/perfect-scrollbar/perfect-scrollbar.css" type="text/css" rel="stylesheet" media="screen" />


  <!-- CORE CSS FRAMEWORK - END -->

  <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START -->
  <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END -->

  <!-- CORE CSS TEMPLATE - START -->


  <link href="assets/css/style.css" type="text/css" rel="stylesheet" media="screen" id="main-style" />
  <!-- CORE CSS TEMPLATE - END -->



</head>
<!-- END HEAD -->

<!-- BEGIN BODY -->


<body class="   html" data-header="light" data-footer="light" data-header_align="app" data-menu_type="left"
  data-menu="light" data-menu_icons="on" data-footer_type="left" data-site_mode="light" data-footer_menu="show"
  data-footer_menu_style="light">
  <div class="preloader-background">
    <div class="preloader-wrapper">
      <div class="orig">

        <div class="dot orig three "></div>
        <div class="dot orig two "></div>
        <div class="dot orig one "></div>
      </div>

    </div>
  </div>



  <!-- SIDEBAR - START -->

  <!-- MAIN MENU - START -->



  <!-- MAIN MENU - END -->



  <!--  SIDEBAR - END --><!-- SIDEBAR - START -->

  <!-- MAIN MENU - START -->



  <!-- MAIN MENU - END -->



  <!--  SIDEBAR - END -->

  <!-- START navigation -->
  <nav class="fix_topscroll logo_on_fixed  topbar navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="index.html" class=" brand-logo ">RJAY</a>

      <a href="index.html" data-target=""
        class="waves-effect waves-circle navicon back-button htmlmode show-on-large "><!--<i class="mdi mdi-arrow-left" data-page=""></i>--></a>


      <a href="#" data-target="slide-nav" class="waves-effect waves-circle navicon sidenav-trigger show-on-large"><i
          class="mdi mdi-menu"></i></a>

      <a href="#" data-target="slide-settings"
        class="waves-effect waves-circle navicon right sidenav-trigger show-on-large"><i
          class="mdi mdi-settings-outline"></i></a>

      <a href="#" data-target="" class="waves-effect waves-circle navicon right nav-site-mode show-on-large"><i
          class="mdi mdi-invert-colors mdi-transition1"></i></a>
      <!-- <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a> -->
    </div>
  </nav>
  <!--<ul id="slide-nav" class="sidenav sidemenu">
    <li class="user-wrap">
      <div class="user-view row">

        <div class="col s9 infoarea">
          <a href="ui-app-profile.html"><span class="name">Emma Bailey</span></a>
          <a href="ui-app-profile.html"><span class="email">emma.bailey@gmail.com</span></a>
        </div>
      </div>




    </li>


    <li class="menulinks">
      <ul class="collapsible">-->
        <!-- Menu Data Start-->
        <!--<li class="sh-wrap">
          <div class="subheader">Navigation</div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="index.html">
              <i class="mdi mdi-home-outline"></i>
              <span class="title">Home Pages</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="ui-apps.html">
              <i class="mdi mdi-arrange-send-to-back"></i>
              <span class="title">Apps</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-components.html">
              <i class="mdi mdi-flask-outline"></i>
              <span class="title">Components</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-pages.html">
              <i class="mdi mdi-palette-swatch"></i>
              <span class="title">Pages</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-gallery.html">
              <i class="mdi mdi-view-dashboard"></i>
              <span class="title">Gallery</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-forms.html">
              <i class="mdi mdi-textbox"></i>
              <span class="title">Forms</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-charts.html">
              <i class="mdi mdi-chart-bubble"></i>
              <span class="title">Charts</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class="waves-effect "><a href="#" data-target="slide-settings" class="sidenav-trigger"><i
                class="mdi mdi-settings-outline"></i><span class="title">Settings</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Prebuilt Apps</div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-socialmedia.html">
              <i class="mdi mdi-account-network"></i>
              <span class="title">Social Media App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-ecommerce.html">
              <i class="mdi mdi-cart-outline"></i>
              <span class="title">Ecommerce App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-blog.html">
              <i class="mdi mdi-square-edit-outline"></i>
              <span class="title">Blog App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-portfolio.html">
              <i class="mdi mdi-widgets   "></i>
              <span class="title">Portfolio App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-news.html">
              <i class="mdi mdi-newspaper"></i>
              <span class="title">News App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-events.html">
              <i class="mdi mdi-movie-roll"></i>
              <span class="title">Events App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-courses.html">
              <i class="mdi mdi-school"></i>
              <span class="title">Online Courses App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-university.html">
              <i class="mdi mdi-certificate"></i>
              <span class="title">University App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-chat.html">
              <i class="mdi mdi-message-outline"></i>
              <span class="title">Chat & Messages App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-mailbox.html">
              <i class="mdi mdi-email-variant"></i>
              <span class="title">Mailbox App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-contacts.html">
              <i class="mdi mdi-contacts"></i>
              <span class="title">Contacts App</span></a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class=" waves-effect   index ">
            <a href="sub-apps-wallet.html">
              <i class="mdi mdi-wallet"></i>
              <span class="title">Payment & Wallet App</span></a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Get in Touch</div>
        </li>
        <li class="lvl1 ">
          <div class="waves-effect ">
            <a href="mailto:email@example.com">
              <i class="mdi mdi-email-outline"></i>
              <span class="title">Email</span> </a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class="waves-effect ">
            <a href="tel:+1 234 567 890">
              <i class="mdi mdi-cellphone-basic"></i>
              <span class="title">Phone</span> </a>
          </div>
        </li>
        <li class="lvl1 ">
          <div class="waves-effect ">
            <a href="sms:+1 234 567 890">
              <i class="mdi mdi-message-text-outline"></i>
              <span class="title">Message</span> </a>
          </div>
        </li>--> <!-- Menu Data End-->


      <!--</ul>
    </li>



    <li class="copy-spacer"></li>
    <li class="copy-wrap">
      <div class="copyright">&copy; Copyright @ themepassion</div>

  </ul>-->
  <!-- END navigation -->


  <ul id="slide-settings" class="sidenav sidesettings ">
    <li class="menulinks">
      <ul class="collapsible">
        <!-- Menu Settings Start-->
        <li class="sh-wrap">
          <div class="subheader">Themes</div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="red">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate red-text text-lighten-2"></i>
              <span class="title">Red</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="orange">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline deep-orange-text text-lighten-2"></i>
              <span class="title">Orange</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="blue">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline blue-text text-lighten-2"></i>
              <span class="title">Blue</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="teal">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline teal-text text-lighten-2"></i>
              <span class="title">Teal</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="pink">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline pink-text text-lighten-2"></i>
              <span class="title">Pink</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="light-green">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline light-green-text text-lighten-2"></i>
              <span class="title">Light Green</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="purple">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline purple-text text-lighten-2"></i>
              <span class="title">Violet</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="green">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline green-text text-lighten-2"></i>
              <span class="title">Green</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings active" data-type="theme" data-value="deep-purple">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline deep-purple-text text-lighten-2"></i>
              <span class="title">Purple</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="amber">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline amber-text"></i>
              <span class="title">Yellow</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="indigo">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline indigo-text text-lighten-2"></i>
              <span class="title">Indigo</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="blue-grey">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline blue-grey-text text-lighten-2"></i>
              <span class="title">Blue Grey</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="brown">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline brown-text text-lighten-2"></i>
              <span class="title">Brown</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="cyan">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline cyan-text text-lighten-2"></i>
              <span class="title">Cyan</span> </a>
          </div>
        </li>
        <li class="lvl1  theme">
          <div class="waves-effect appsettings " data-type="theme" data-value="grey">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline grey-text text-darken-2"></i>
              <span class="title">Black</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Site Mode</div>
        </li>
        <li class="lvl1  site_mode">
          <div class="waves-effect appsettings active" data-type="site_mode" data-value="light">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Light Mode</span> </a>
          </div>
        </li>
        <li class="lvl1  site_mode">
          <div class="waves-effect appsettings " data-type="site_mode" data-value="dark">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Dark Mode</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <!--<li class="sh-wrap">
          <div class="subheader">Header Style</div>
        </li>
        <li class="lvl1  header">
          <div class="waves-effect appsettings active" data-type="header" data-value="light">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Light Header</span> </a>
          </div>
        </li>
        <li class="lvl1  header">
          <div class="waves-effect appsettings " data-type="header" data-value="dark">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Dark Header</span> </a>
          </div>
        </li>
        <li class="lvl1  header">
          <div class="waves-effect appsettings " data-type="header" data-value="colored">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Colored Header</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Header Alignment</div>
        </li>
        <li class="lvl1  header_align">
          <div class="waves-effect appsettings " data-type="header_align" data-value="left">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Left Align Header</span> </a>
          </div>
        </li>
        <li class="lvl1  header_align">
          <div class="waves-effect appsettings " data-type="header_align" data-value="center">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Center Align Header</span> </a>
          </div>
        </li>
        <li class="lvl1  header_align">
          <div class="waves-effect appsettings " data-type="header_align" data-value="right">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Right Align Header</span> </a>
          </div>
        </li>
        <li class="lvl1  header_align">
          <div class="waves-effect appsettings active" data-type="header_align" data-value="app">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">App Based Align Header</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Menu Style</div>
        </li>
        <li class="lvl1  menu">
          <div class="waves-effect appsettings active" data-type="menu" data-value="light">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Light Menu</span> </a>
          </div>
        </li>
        <li class="lvl1  menu">
          <div class="waves-effect appsettings " data-type="menu" data-value="dark">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Dark Menu</span> </a>
          </div>
        </li>
        <li class="lvl1  menu">
          <div class="waves-effect appsettings " data-type="menu" data-value="colored">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Colored Menu</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Menu Icons</div>
        </li>
        <li class="lvl1  menu_icons">
          <div class="waves-effect appsettings active" data-type="menu_icons" data-value="on">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Menu Icons Show</span> </a>
          </div>
        </li>
        <li class="lvl1  menu_icons">
          <div class="waves-effect appsettings " data-type="menu_icons" data-value="off">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Menu Icons Hide</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Page Footer Style</div>
        </li>
        <li class="lvl1  footer">
          <div class="waves-effect appsettings active" data-type="footer" data-value="light">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Light Footer</span> </a>
          </div>
        </li>
        <li class="lvl1  footer">
          <div class="waves-effect appsettings " data-type="footer" data-value="dark">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Dark Footer</span> </a>
          </div>
        </li>
        <li class="lvl1  footer">
          <div class="waves-effect appsettings " data-type="footer" data-value="colored">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Colored Footer</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Page Footer Type</div>
        </li>
        <li class="lvl1  footer_type">
          <div class="waves-effect appsettings " data-type="footer_type" data-value="minimal">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Minimal Footer</span> </a>
          </div>
        </li>
        <li class="lvl1  footer_type">
          <div class="waves-effect appsettings active" data-type="footer_type" data-value="left">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Left Aligned Footer</span> </a>
          </div>
        </li>
        <li class="lvl1  footer_type">
          <div class="waves-effect appsettings " data-type="footer_type" data-value="center">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Centered Footer</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Fixed Footer Menu</div>
        </li>
        <li class="lvl1  footer_menu">
          <div class="waves-effect appsettings active" data-type="footer_menu" data-value="show">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Show Fixed Footer Menu</span> </a>
          </div>
        </li>
        <li class="lvl1  footer_menu">
          <div class="waves-effect appsettings " data-type="footer_menu" data-value="hide">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Hide Fixed Footer Menu</span> </a>
          </div>
        </li>
        <li class="sep-wrap">
          <div class="divider"></div>
        </li>
        <li class="sh-wrap">
          <div class="subheader">Fixed Footer Menu Style</div>
        </li>
        <li class="lvl1  footer_menu_style">
          <div class="waves-effect appsettings active" data-type="footer_menu_style" data-value="light">
            <a href="#!">
              <i class="mdi mdi-checkbox-intermediate"></i>
              <span class="title">Light Fixed Menu</span> </a>
          </div>
        </li>
        <li class="lvl1  footer_menu_style">
          <div class="waves-effect appsettings " data-type="footer_menu_style" data-value="dark">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Dark Fixed Menu</span> </a>
          </div>
        </li>
        <li class="lvl1  footer_menu_style">
          <div class="waves-effect appsettings " data-type="footer_menu_style" data-value="colored">
            <a href="#!">
              <i class="mdi mdi-checkbox-blank-outline"></i>
              <span class="title">Colored Fixed Menu</span> </a>
          </div>
        </li> --><!-- Menu Settings End-->
      </ul>
    </li>
  </ul>
  <div class="menu-close"><i class="mdi mdi-close"></i></div>

  <div class="content-area">
    <div class="container  is-pagetitle">
      <div class="section">
        <h5 class="pagetitle">Select Option Fields</h5>
      </div>
    </div>

    <div class="container">
      <div class="section ui-select">


        <div class="row ">
          <div class="col s12 pad-0">



            <form action="" method="post">
              <!-- select multiple -->
              <div class="">

                <div class="input-field sel-wrap sel-wrap col s12">
                  <select name="start">
                    <option>Choose Your Location</option>
                    <option>Ahangama</option>
                    <option>Anuradhapura</option>
                    <option>Arugambay</option>
                    <option>Benthota</option>
                    <option>BIA</option>
                    <option>Colombo</option>
                    <option>Dambulla</option>
                    <option>Dikwella</option>
                    <option>Ella</option>
                    <option>Galle</option>
                    <option>Hikkaduwa</option>
                    <option>Hiriketiya</option>
                    <option>Kandy</option>
                    <option>Mirissa</option>
                    <option>Negambo</option>
                    <option>Sigiriya</option>
                    <option>Tangalle</option>
                    <option>Trincomalee</option>
                    <option>Udawalawa</option>
                    <option>Unawatuna</option>
                    <option>Weligama</option>
                    <option>Yala</option>
                  </select>
                  <label>Select Start Location</label>
                </div>



              </div>


              <!-- select with optgroups -->
              <div class="">
                <div class="input-field sel-wrap col s12">
                  <select name="end">
                    <option>Choose Your End Location</option>
                    <option>Ahangama</option>
                    <option>Anuradhapura</option>
                    <option>Arugambay</option>
                    <option>Benthota</option>
                    <option>BIA</option>
                    <option>Colombo</option>
                    <option>Dambulla</option>
                    <option>Dikwella</option>
                    <option>Ella</option>
                    <option>Galle</option>
                    <option>Hikkaduwa</option>
                    <option>Hiriketiya</option>
                    <option>Kandy</option>
                    <option>Mirissa</option>
                    <option>Negambo</option>
                    <option>Sigiriya</option>
                    <option>Tangalle</option>
                    <option>Trincomalee</option>
                    <option>Udawalawa</option>
                    <option>Unawatuna</option>
                    <option>Weligama</option>
                    <option>Yala</option>
                  </select>
                  <label>Select End Location</label>
                </div>

                <!-- select with optgroups -->
                <div class="input-field sel-wrap col s12">
                  <select name="vehicle">
                    <option>Choose Vehicle</option>
                    <option>Flex car</option>
                    <option>Sedan</option>
                    <option>Van</option>
                  </select>
                  <label>Select Vehicle</label>
                </div>

              </div>

              <button type="submit" name="submit1" class="btn btn-success">Calculate</button>
            </form>

            <div class="pad-15">

              <div class="row">
                <div class="input-field col s12">
                  <input id="ndistance" type="text" class="validate">
                  <label for="first_name1">Distance</label>
                </div>
              </div>

              <div class="row">
                <div class="input-field col s12">
                  <input id="nprice" type="text" class="validate">
                  <label for="first_name1">Price</label>
                </div>
              </div>
            </div>

          </div>
        </div>


      </div>
    </div>


<?php
  if (isset($_POST["submit1"]))
  {
    $startlocation = $_POST["start"];
    $endlocation = $_POST["end"];
    $vehicle = $_POST["vehicle"];

    /*?>
    <script>alert("<?php echo $vehicle; ?>");</script>
    <?php*/

    $res = mysqli_query($link, "select * from distance where start='$startlocation' && end='$endlocation'");
    while ($row = mysqli_fetch_array($res)) {
      $distance = $row["distance"];
    }

    if ($vehicle == "Flex car") {
      $price = $distance * 125;
    }elseif ($vehicle == "Sedan") {
      $price = $distance * 150;
    }elseif ($vehicle == "Van") {
      $price = $distance * 200;
    }

    /*?>
    <script>alert("<?php echo $price; ?>");</script>
    <?php*/

    ?>
    <script>
    document.getElementById("ndistance").value = "<?php echo $distance.' '.'Km'; ?>";
    document.getElementById("nprice").value = "<?php echo 'Rs.'.' '. $price.' '.'/='; ?>";
    </script>
    <?php

    /*?>
    <script>alert("<?php echo $price; ?>");</script>
    <?php*/



  }
?>



    <footer class="page-footer center">
      <div class="container footer-content">
        <div class="row">
          <div class="">
            <h5 class="logo">RJAY</h5>
          </div>
          <div class="link-wrap">

            <ul class="link-ul">
              <li><a class="" href="#!"><i class="mdi mdi-phone"></i> +94 77 576 9900</a></li>
              <li><a class="" href="#!"><i class="mdi mdi-email"></i> rjaytours@gmail.com</a></li>
              <li><a class="" href="#!"><i class="mdi mdi-map-marker"></i> 99, thisara uyana, kamburugamuwa, matara</a></li>
            </ul>
            <ul class="social-wrap">
              <li class="social">
                <a class="" href="#!"><i class="mdi mdi-facebook"></i></a>
                <a class="" href="#!"><i class="mdi mdi-twitter"></i></a>
                <a class="" href="#!"><i class="mdi mdi-dribbble"></i></a>
                <a class="" href="#!"><i class="mdi mdi-google-plus"></i></a>
                <a class="" href="#!"><i class="mdi mdi-linkedin"></i></a>

              </li>
            </ul>
          </div>
        </div>


      </div>


      <div class="footer-copyright">
        <div class="container">
          &copy; Copyright <a class="" href="https://webtwozero.com/">WEB Two Zero</a>. All
          rights reserved.
        </div>
      </div>
    </footer>



    <div class="backtotop">
      <a class="btn-floating btn primary-bg">
        <i class="mdi mdi-chevron-up"></i>
      </a>
    </div>



  </div><!--.content-area-->

  <div class="footer-menu circular">
    <ul>
      <li>
        <a href="#"> <i class="mdi mdi-open-in-app"></i>
          <span>About</span>
        </a>
      </li>
      <li>
        <a href="#"> <i class="mdi mdi-palette-swatch"></i>
          <span>Pages</span>
        </a>
      </li>
      <li>
        <a href="index.php"> <i class="mdi mdi-home-outline"></i>
          <span>Home</span>
        </a>
      </li>
      <li>
        <a href="#"> <i class="mdi mdi-flask-outline"></i>
          <span>Components</span>
        </a>
      </li>
      <li>
        <a href="#"> <i class="mdi mdi-view-dashboard"></i>
          <span>Contact</span>
        </a>
      </li>

    </ul>
  </div>








  <script src="assets/js/pwa.js"></script>

  <!-- LOAD FILES AT PAGE END FOR FASTER LOADING -->

  <!-- CORE JS FRAMEWORK - START -->
  <script src="modules/jquery/jquery-2.2.4.min.js"></script>
  <script src="modules/materialize/materialize.js"></script>
  <script src="modules/perfect-scrollbar/perfect-scrollbar.min.js"></script>
  <script src="assets/js/variables.js"></script>
  
  <!-- CORE JS FRAMEWORK - END -->


  <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START -->
  <script type="text/javascript">
    $("select").formSelect();
  </script>
  <script src="assets/js/common.js"></script><!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END -->


  <!-- CORE TEMPLATE JS - START -->
  <script src="modules/app/init.js"></script>
  <script src="modules/app/settings.js"></script>

  <script src="modules/app/scripts.js"></script>

  <!-- END CORE TEMPLATE JS - END -->


  <script src="assets/js/preloader.js"></script>
</body>

</html>